(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customFileUpload', function() {
    return {
      controllerAs: 'ctrl',
      controller: function CustomFileUploadCtrl($scope, $sce, $element, $timeout, $log, widgetNameFactory) {
  var ctrl = this;
  this.name = widgetNameFactory.getName("fileUpload");
//  this.name = "fileUpload";
  this.filename = '';
  this.filemodel = '';
  this.editMode = false;
  this.existingFile = false;

  


  this.downloadUrl = '';
  this.newFile=true;
  this.isFile=true;



  var input = $element.find('input');
  var form = $element.find('form');

  this.preventFocus = function($event) {
    $event.target.blur();
  };

  input.on('change', forceSubmit);
  $scope.$on('$destroy', function() {
    input.off('change', forceSubmit);
  });

  $scope.$watch('properties.url', function(newUrl, oldUrl){
    ctrl.urlUpload = $sce.trustAsResourceUrl(newUrl);
    if (newUrl === undefined) {
      $log.warn('you need to define a url for pbUpload');
    }
  });

  $scope.$watch('properties.currentFile', function(newCurrentFile, oldCurrentFile){
    if (angular.isObject(newCurrentFile) && newCurrentFile.fileName) {
      ctrl.downloadUrl = "/bonita/portal/" + newCurrentFile.url;
      ctrl.filename = newCurrentFile.fileName;
      ctrl.newFile = false;
    }
  });

  $scope.$watch('properties.deleteFile', function(newDeleteFile){
    if (!newDeleteFile) {
      $scope.properties.deleteFile = false;
    }
  });

  $scope.$watch('properties.newFile', function(newFile){
    if (!newFile) {
      $scope.properties.newFile = null;
    }
  });

  //the filename displayed is not bound to the value as a bidirectionnal
  //bond, thus, in case the value is updated, it is not reflected
  //to the filename (example with the BS-14498)
  //we watch the value to update the filename and the upload widget state
  $scope.$watch(function(){return $scope.properties.newFile;}, function(newValue){
    if (newValue && newValue.filename) {
      ctrl.filemodel = true;
      ctrl.filename = newValue.filename;
    } else if (!angular.isDefined(newValue)) {
      delete ctrl.filemodel;
      delete ctrl.filename;
    }
  });


  if (!$scope.properties.isBound('newFile')) {
    $log.error('the pbUpload property named "newFile" need to be bound to a variable');
  } 

  if ($scope.properties.isBound('existingFile') && angular.isObject($scope.properties.existingFile)) {
      this.editMode = false;
      this.existingFile = true;
  } 

  this.clear = function () {
    ctrl.filename = '';
    ctrl.filemodel = '';
    ctrl.newFile=true;
    ctrl.isFile=true;

    $scope.properties.newFile = null;
  }

  this.deleteCurrentFile = function() {
    ctrl.newFile=true;
    ctrl.filename = '';
    ctrl.filemodel = '';
    $scope.properties.currentFile = null;
    $scope.properties.deleteFile = true;
  }

  this.edit = function() {
    console.log("FileUploadWidget: edit");
    ctrl.newFile=true;
    ctrl.editMode=true;
    input.required = true;
    ctrl.filemodel = '';
    ctrl.isFile = true;

  }

this.showUrlDoc = function () {
	console.log("FileUploadWidget: showUrl");
    ctrl.isFile = false;
	$scope.properties.deleteFile=false;
  }
  
  this.showUpload = function() {
	console.log("FileUploadWidget: showUpload");
    ctrl.isFile = true;
    ctrl.filename = $scope.properties.currentFile.fileName
  }
  this.cancelEdit = function() {
    ctrl.newFile=false;
    ctrl.editMode=false;
    ctrl.filemodel = '';
    $scope.properties.newFile = null;
    ctrl.filename = $scope.properties.currentFile.fileName;
  }

  this.uploadError = function (error) {
    $log.warn('upload fails too', error);
    ctrl.filemodel = '';
    ctrl.filename = "Upload failed";
  }

  this.startUploading = function() {
    console.log("FileUploadWidget: startUploading");
    ctrl.filemodel = '';
    ctrl.filename  = 'Uploading...';
  }

  this.uploadComplete = function(response) {
    console.log("FileUploadWidget: uploadComplete response="+angular.toJson(response));
  
    //when the upload widget return a String, it means an error has occurred (with a html document as a response)
    //if it's not a string, we test if it contains some error message
    if(angular.isString(response) || (response && response.type && response.message)){
      $log.warn('upload fails');
      ctrl.filemodel = '';
      ctrl.filename = 'Upload failed';
      $scope.properties.errorContent = angular.isString(response) ? response : response.message;
      return;
    }
    $scope.properties.deleteFile = false;

    $scope.properties.newFile = response;
    
  }
  
  this.getClassIsFile = function () {
	if (ctrl.isFile)
		return "btn btn-success";
	else
		return "btn btn-primary";
  }
  this.getClassIsUrl = function () {
	if (ctrl.isFile)
		return "btn btn-primary";
	else
		return "btn btn-success";
  }
  

  function forceSubmit(event) {
    if(!event.target.value) {
      return;
    }

    form.triggerHandler('submit');
    form[0].submit();
    event.target.value = null;
  }
}
,
      template: '<div ng-class="{\n    \'form-horizontal\': properties.labelPosition === \'left\' && !properties.labelHidden,\n    \'row\': properties.labelPosition === \'top\' && !properties.labelHidden || properties.labelHidden\n    }">\n    <div class="form-group">\n        <label\n            ng-if="!properties.labelHidden"\n            ng-class="{ \'control-label--required\': properties.required }"\n            class="control-label col-xs-{{ !properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 12 }}">\n            {{ properties.label | uiTranslate }}\n        </label>\n        <div class="col-xs-{{ 12 - (!properties.labelHidden && properties.labelPosition === \'left\' ? properties.labelWidth : 0) }}">\n           \n                <div class="input-group">\n                  \n					<form action="{{ctrl.urlUpload}}"\n						 ng-upload="ctrl.uploadComplete(content)"\n						 ng-upload-loading="ctrl.startUploading()"\n						 error-catcher="ctrl.uploadError(error)"\n						 upload-options-enable-csrf\n						 upload-options-csrf-param="CSRFToken">\n            \n						<input type="text" ng-focus="ctrl.preventFocus($event)" placeholder="{{properties.placeholder | uiTranslate}}" value="{{ctrl.filename}}" \n								class="form-control" \n								ng-show="ctrl.isFile === true"/>\n						\n					  \n						<!-- using a ng-if broke the file loading : so use a ng-show -->\n						<input class="custom-file-upload-input"\n								 ng-class="{\'file-upload-input--disabled\':$isUploading}"\n								 name="{{ctrl.name}}" type="file"\n								 ng-required="properties.required"\n								 ng-model="ctrl.filemodel"\n								 ng-show="ctrl.isFile === true "\n								 />\n					</form>\n                    <!-- URL text -->\n                    <input type="text" ng-readonly="properties.readOnly" class="form-control"\n                       placeholder="{{properties.placeholder | uiTranslate}}" \n                       ng-model="ctrl.url"\n					   ng-if="ctrl.isFile === false"\n                       />                             \n                             \n					<div class="input-group-btn" ng-class="{\'btn-default disabled\':$isUploading, \'btn-primary\':!$isUploading}" >\n				<table>\n				<tr><td>\n				    <!-- show it if we are in URL mode -->\n					<button uib-tooltip="Upload file" tooltip-placement="top" tooltip-popup-delay="300" class="{{ctrl.getClassIsFile()}}" \n								ng-click="ctrl.showUpload()" \n								ng-if="! properties.readOnly">\n                              <i class="glyphicon" ng-class="{\'glyphicon-cloud-upload\':$isUploading, \'glyphicon-paperclip\':!$isUploading}" ></i>\n					</button>\n					\n				</td><td>\n                    <a uib-tooltip="Download file" tooltip-placement="top" tooltip-popup-delay="300" \n                         class="btn btn-primary" \n                         ng-if="!ctrl.newFile && ctrl.isFile == true" ng-href="{{ctrl.downloadUrl}}">\n                        <i class="glyphicon glyphicon-download"></i>\n                    </a>\n				<!--</td><td>\n                    <button uib-tooltip="Edit current file" tooltip-placement="top" tooltip-popup-delay="300" class="btn btn-primary" \n                        ng-click="ctrl.edit()" \n                        ng-if="!ctrl.newFile && !properties.readOnly">\n                        <i class="glyphicon glyphicon-tag"></i>\n                    </button>\n				-->\n				</td><td>\n                    <button uib-tooltip="Cancel edit" tooltip-placement="top" tooltip-popup-delay="300" \n                            class="btn btn-primary" \n                            ng-click="ctrl.cancelEdit()" \n                            ng-if="ctrl.editMode">\n                        <i class="glyphicon glyphicon-ban-circle" ></i>\n                    </button>\n				</td><td>\n					<button uib-tooltip="Clear" tooltip-placement="top" tooltip-popup-delay="300" \n							class="btn btn-primary"\n							ng-click="ctrl.clear()"							\n							ng-if="ctrl.filemodel"  >\n							<i class="glyphicon glyphicon-remove-circle"></i>\n							<span class="hide" translate>Close</span>\n					</button>\n				</td><td>\n                    <button uib-tooltip="Delete file" tooltip-placement="top" tooltip-popup-delay="300" \n                        class="btn btn-primary" \n                        ng-click="ctrl.deleteCurrentFile()" \n                        ng-if="!ctrl.newFile && !properties.readOnly && ctrl.isFile == true">\n                        <i class="glyphicon glyphicon-trash" ></i>\n                    </button>\n				</td><td>\n                    <button uib-tooltip="Give the url to the document" tooltip-placement="top" tooltip-popup-delay="300" class="{{ctrl.getClassIsUrl()}}"\n                        ng-click="ctrl.showUrlDoc()" \n                        ng-if="! properties.readOnly">\n                        <i class="glyphicon glyphicon-globe" ></i>\n                    </button>\n				</td><td>\n				</tr></table>\n                </div> <!-- end div disabled -->\n                 \n                </div>\n        </div> <!-- end div class 12 -->\n\n\n        <div ng-messages="$form[ctrl.name].$dirty && $form[ctrl.name].$error " ng-messages-include="forms-generic-errors.html" role="alert"></div>\n        \n    </div> <!-- end div class="group"-->\n</div>'
    };
  });
